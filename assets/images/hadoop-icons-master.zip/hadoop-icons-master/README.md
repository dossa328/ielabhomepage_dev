##Hortonworks Icons for Hadoop

We’ve built a small set of Hadoop-related icons that might help you next time you need that picture focusing on the intended function of various components. If you need the official logos then you can grab those from the various Apache project sites. 

Add an issue to request new icons. See the [slideshare](http://www.slideshare.net/hortonworks/icons-for-hadoop) for style guidance and some thoughts on how to use them for best effect, but feel free to ignore us and use them however you like.

Included in this repo are:

* HiRes PNG images for Physical/Network and Hadoop-related Software Components
* EPS file for images.
* Omnigraffle Stencil
* Microsoft Visio Stencil



![Icon Set](Hortonworks_Icons_For_Hadoop.png?raw=true)


